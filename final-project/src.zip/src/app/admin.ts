export class Admin {
    adminId?: number;
    name!: string; // Definite assignment assertion
    emailId!: string;
    phoneNumber!: string;
    password!: string;
}
