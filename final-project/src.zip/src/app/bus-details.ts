import { Ticket } from "./tickets";


export class BusDetails {
  busNumber: number | undefined;
  arrivalDate: string | undefined; // Assuming string representation of LocalDate
  arrivalTime: string | undefined; // Assuming string representation of LocalTime
  totalSeats: number | undefined;
  availableSeats: number | undefined;
  source: string | undefined;
  destination: string | undefined;
  ticketPrice: number | undefined;
  tickets: Ticket[] | undefined;
}