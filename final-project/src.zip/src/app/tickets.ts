import { BusDetails } from "./bus-details";

export class Ticket {
  ticketId!: number;
  passName: string | undefined;
  passCount:number| undefined;
  busNumber: number | undefined;
  ticketPrice: number | undefined;
  source: string | undefined; 
  destination:string|undefined;
  busDetails: BusDetails = new BusDetails;
  passengerEmail: string | undefined;

 }
